package com.example.imageview

class Cats {
    val cats = arrayOf(
        R.drawable._cat1,
        R.drawable._cat2,
        R.drawable._cat3,
        R.drawable._cat4,
        R.drawable._cat5
    )
}